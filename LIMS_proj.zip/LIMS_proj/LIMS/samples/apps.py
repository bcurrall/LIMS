from django.apps import AppConfig


class SamplesConfig(AppConfig):
    name = 'samples'
