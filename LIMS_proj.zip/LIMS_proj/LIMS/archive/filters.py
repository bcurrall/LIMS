import django_filters
from django_filters import rest_framework as filters
from .models import Sample, Individual



class SampleFilter(filters.FilterSet):

    class Meta:
        model = Sample
        fields = ['individual', 'type']


class IndividualFilter(filters.FilterSet):

    class Meta:
        model = Individual
        fields = ['project_id', 'species']
