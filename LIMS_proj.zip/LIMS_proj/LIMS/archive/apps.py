from django.apps import AppConfig


class ArchiveConfig(AppConfig):
    name = 'archive'
